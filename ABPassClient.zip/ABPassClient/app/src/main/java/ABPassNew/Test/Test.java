package ABPassNew.Test;

import ABPassNew.Client.Client;
import ABPassNew.Model.*;
import ABPassNew.Server.Server;
import ABPassNew.Verifier.Movie;
import ABPassNew.Verifier.Verifier;


/**
 * Created by 41861 on 2017/6/27.
 */
public class Test {
    public static void main(String[] args) {



    }
}
