package ABPassNew.Model;

/**
 * Created by 41861 on 2017/6/19.
 */
public  enum AttributeEnum {
    BirthYeah, Identity,Sex,Nationality ,BirthPlace,CardType,IssuancePlace,EyeColor,HairColor,VisualStatus ,HearStatus,PhysicalStatus,SocialBenefitExist,SocialBenefitStatus,MemberShip,Doctor,Teacher,Professor,BA,MS
}
